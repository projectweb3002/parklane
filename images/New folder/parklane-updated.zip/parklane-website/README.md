# Parklane website – 15-page version

`site/` = the finished website (exactly 15 HTML files). Upload its CONTENTS to your hosting (GitHub Pages works).

## How it is built
`config.js` (all content) → `node build.js` → `site/` (HTML pages + `site/js/data.js`).
**After ANY change to `config.js` you must run `node build.js`**, otherwise the website does not change.
Do not edit the generated `.html` files or `site/js/data.js` by hand – the next build overwrites them.
(`site/css/style.css`, `site/js/main.js` and `site/images/` are NOT generated; edit them directly.)

```
node build.js                       # build
cd site && python3 -m http.server   # test at http://localhost:8000  (or: npx serve site)
```
The build prints a WARNING for every image path in `config.js` that does not exist (the built-in illustration is used instead).

## The 15 pages
404, about, agents, buy, contact, index, location, login, privacy, properties, register, rent, sell, terms, valuation (all `.html`).

Individual records are shown on the same page through a URL parameter:
- `properties.html?property=willow-residence`
- `agents.html?agent=isha-kapoor`
- `location.html?location=delhi-ncr`

An unknown value shows a "not found" message with links back (and `noindex`).

## Editing content (all in `config.js`)
- **Property**: edit its line in `properties: [...]` (title, city, hood, type, listing, price, beds, baths, area, status, agent, images). `slug` is its URL id – changing it changes its link.
  Optional per-property SEO: `seo: { title: '...', description: '...' }`.
  Shared detail text (about / features / amenities) is under `detail:`.
- **Agent**: `agents: [...]` (`slug`, name, role, area, langs, `photo`, optional `bio`). A property belongs to an agent through its `agent` number (0 = first agent).
- **Location**: `locations: [...]` (name, text, image). A property appears on a location page when its `city` equals the location `name`. The URL id is the name in lowercase-with-dashes (Delhi NCR → `delhi-ncr`).

## Adding / replacing property photos
1. Copy the file into `site/images/` (any of .jpg .jpeg .png .webp).
2. Add its path to that property's `images: [...]` in `config.js`. The FIRST one is the card image and main gallery image; any number of photos is supported.
3. Optional alt text: `{ src: 'images/x.jpg', alt: 'Living room of ...' }`.
4. Run `node build.js`.

## Before going live
- `seo.siteUrl` in `config.js` → your real domain, then rebuild (fixes canonical links, sitemap, social previews).
- `forms.action` → your form service URL (forms are demo-only while it is empty).
- Submit `sitemap.xml` in Google Search Console.


## Content and SEO update (24 October 2026)

The About, Agents, Privacy Policy and Terms pages have been refreshed with fuller copy and page-specific SEO titles/descriptions. The content source is `config.js`; run `node build.js` from this folder after editing.

### Before publishing
- In `config.js`, replace `https://your-domain-here.com` with the final live website origin (no trailing slash). This is used for canonical URLs, social metadata and sitemap generation.
- Confirm that agent names, roles, languages, photos and credentials are accurate and authorised. Current profiles are sample content and should not be presented as verified real people without confirmation.
- Confirm property details and availability before presenting listings as live inventory.
- The Privacy Policy and Terms are general drafts, not legal advice. Match the privacy policy to the actual hosting, form processing, analytics, cookies and retention practices, and obtain legal review before launch.
- Configure a real form endpoint before expecting enquiries to be delivered. Forms are currently in demo mode unless `forms.action` is configured.
- The build reports a missing `images/2.png`; add the intended image or change the image path in `config.js` to remove that warning.


## Design refinement update (25 October 2026)

See `CHANGES.md` for the full list. Quick reference:

- **Theme**: light/dark toggle in the header. Tokens live in the top of `site/css/style.css` (`:root` and `:root[data-theme=dark]`). Header, footer, Explore Locations and Selling stay identical in both themes (`.fixed` class + shared gradient variables `--grad-start` / `--grad-end`).
- **Fonts**: put licensed files in `site/fonts/` (names in `site/fonts/README.txt`), then run `node build.js` - it writes `site/css/fonts.css`. Nothing is loaded from Google Fonts any more.
- **Contact + social links**: ONE place, `contact: {...}` in `config.js` (email, WhatsApp number, Instagram URL, phone). Empty values show as placeholder icons linking to `contact.html`, and the build prints a WARNING for each.
- **Agent card** on property pages: edit `agents`, `agentIntro` and `agentSampleNote` in `config.js`. Optional per-agent `phone`, `email`, `photo`, `intro`; set `verified: true` on an agent to remove their "Sample profile" tag.
- **About page**: structure is now fields in `pages.about` (config.js) instead of one HTML string.
