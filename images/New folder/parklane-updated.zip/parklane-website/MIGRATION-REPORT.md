# Migration report

Backup of the untouched original: keep your original `parklane-website.zip` (nothing was deleted from it).

## Old files → new home
| Old (31 pages) | Now |
|---|---|
| `properties/<12 slugs>.html` | `properties.html?property=<slug>` |
| `agents/<4 slugs>.html` | `agents.html?agent=<slug>` |
| `locations/<4 slugs>.html` | `location.html?location=<slug>` (new `location.html` also lists all locations) |
| all other pages | unchanged file names |

## Counts
12 properties, 4 agents, 4 locations preserved (generated from `config.js` into `site/js/data.js`). 50 property photos mapped (all 50 `houseN-M.webp` files in use, none duplicated).

| Property | Photos | Note |
|---|---|---|
| willow-residence | house1-1..6 (6) | |
| aravalli-heights | house2-1..6 (6) | |
| courtyard-house | house3-1..6 (6) | |
| palm-grove-villa | house4-1..6 (6) | |
| glasshouse | house5-1..4 (4) | files 5-5, 5-6 were listed in config but do not exist – removed |
| meadowview | house6-1..6 (6) | **review** – set mixes storefront, daycare, interiors and city views |
| ridge-estate | house7-1..6 (6) | |
| gardenia | house8-1..6 (6) | |
| sunrise-loft | house9-1..4 (4) | files 9-5, 9-6 were listed but do not exist – removed |
| orchard-lane, skyline-penthouse, banyan-bungalow | none | no photos exist; built-in illustrations shown |

## Things to review
- Photo content vs. listing data: e.g. `house1` shows a small brick bungalow but "The Willow Residence" is listed as a 4-bed, 3,800 sq ft Villa. Grouping by filename is consistent, but check each set suits its listing.
- `images/2.png` (hero + social-share image) is referenced in `config.js` but is not in the zip. The build falls back to the built-in hero illustration and omits `og:image` until you add the file.
- `config.js` had drifted from the shipped `site/` (logo path `images/logo.png` didn't exist; hero title lost the word "Your"). Fixed: logo → `logob.png`, favicon → `logow.png`, title restored.
- Page titles end with "Meridian Estates (Demo)" (`brand.titleSuffix`) while the brand is Parklane. Left unchanged – your call.
- `404.html` uses root-absolute links (`/index.html`). Fine on a custom domain; on a GitHub Pages *project* site (user.github.io/repo/) those links would miss the repo folder.

## SEO / hosting trade-offs
- Record URLs are now query strings. Google can index them (each has a self-referencing canonical, title, description and JSON-LD set by JavaScript), but it renders JS in a second pass and treats parameter URLs as weaker than static paths. Expect slower/less reliable indexing than the old separate files.
- The static HTML of `properties.html`, `agents.html` and `location.html` carries the list-page metadata; per-record metadata appears after JavaScript runs. Social-share crawlers (WhatsApp, Facebook) do not run JS, so shared record links preview the generic page.
- All record URLs are listed in `sitemap.xml`. Old `/properties/x.html`-style URLs no longer exist; on GitHub Pages they return the 404 page (no server redirects possible). If the site was already indexed, tell me the live URLs and I can add redirect stubs – that would mean extra HTML files, so I did not.
