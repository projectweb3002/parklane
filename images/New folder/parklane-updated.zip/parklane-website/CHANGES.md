# Parklane refinement - summary of changes

Existing architecture kept: `config.js` -> `node build.js` -> `site/`. No frameworks or dependencies added. File names and URLs are unchanged (the only new files are listed at the bottom).

## What changed
1. **Dark / light toggle** - circular sun/moon button in the header on all 15 pages. Light = #FFFFFF, dark = #000000. Saved in `localStorage` ("theme"), applied by a tiny inline script in `<head>` before first paint (no flash), synced across open tabs. With no saved choice it follows the visitor's system setting (as the old CSS already did). Button label updates ("Switch to dark/light mode"), visible focus ring.
2. **Header + footer** - same #1D330F -> #6A9322 gradient in both themes, white logo mark, white text. Explore Locations (sand) and Selling (sage) use a `.fixed` token scope so they look the same in both modes; property photos are never filtered.
3. **Typography** - Canela for H1; Neue Montreal for H2, H3 and the "Parklane" logo text (and body). Font files were not in the project, so `@font-face` is generated automatically from `site/fonts/` once you add them (see `site/fonts/README.txt`). Until then, fallbacks (Georgia / Helvetica-Arial) show. The Google Fonts links (Inter Tight, Playfair) were removed.
4. **Agent section (property details)** - full profile card: portrait, name, designation, phone, email, area/languages, intro, "Schedule a visit" button (scrolls to and focuses the existing viewing form), plus a WhatsApp button once a number is configured. No agent photo or contact details exist in the project, so the portrait is a labelled "PHOTO PLACEHOLDER", phone/email show "to be added", and a "Sample profile" tag is shown.
5. **Hero** - new H1 "Find a place that feels like home." with short supporting line, primary CTA "Explore properties", secondary "Discover locations" (scrolls to the locations section). Search filters unchanged. Hero image is now `house3-4.webp` (the old `images/2.png` never existed).
6. **About page** - restructured: heading + intro + CTAs, value proposition, four differentiators, places/locations, closing CTA with social icons.
7. **Social/contact links** - Instagram, WhatsApp (`wa.me`), Email (opens a Gmail compose window) in the About page, Contact page and footer. All driven by `contact` in `config.js`.
8. **Explore Locations** - four tall (3:4) rounded cards: 4 per row on desktop, 2 on tablet, swipeable row on mobile. Image zoom on hover, property count from real listings. Same cards on `location.html`.
9. **Images** - hero, locations, selling section, About, Sell, Valuation, Contact and the three insight cards now have images, using existing project photos with descriptive alt text; below-the-fold images are lazy-loaded and sit in fixed-ratio frames.
10. **Fixes made along the way** - organisation JSON-LD used footer text as an email address (now only a real email); muted/accent text colours darkened/lightened for contrast; the first search label was hard-coded dark (invisible in dark mode).

## New files
`site/css/fonts.css` (generated), `site/fonts/README.txt`, `site/images/logow-sm.png` + `logob-sm.png` (250 KB -> 7 KB logo copies), `site/images/placeholders/agent-*.svg`.

## You still need to provide
- Font files: NeueMontreal-Regular/Medium/Bold and Canela-Regular (.woff2) in `site/fonts/`.
- Real contact details in `config.js` -> `contact` (email, WhatsApp number, Instagram URL, phone).
- Real agent photos/details (`agents` in `config.js`), then set `verified: true` per agent.
- Location-specific photography: the available photos are generic residential shots, so the four location cards use the closest matches, not images of those cities. Three properties (Orchard Lane, Skyline Penthouse, Banyan Bungalow) still have no photos.
- A higher-resolution hero (the current one is 1024 px wide), and `seo.siteUrl` before launch.

## Known limits
- Header/footer gradient: white text on the lightest end (#6A9322) is ~3.6:1; text near the right edge sits on a mid-tone, and I added a subtle shadow in the footer. Darken `--grad-end` if you need strict AA everywhere.
