/* ==========================================================
   MERIDIAN ESTATES - CONTENT CONFIG
   This is the ONE file to edit for text, listings, agents and images.
   - Colours and fonts: css/style.css (top :root block)
   - Images: put files in the /images folder and write the path,
     e.g. image: 'images/hero.jpg'. Leave '' to keep the built-in
     illustration.
   ========================================================== */
const CONFIG = {

  /* ---------- SEO (used on every page) ----------
     siteUrl: your real domain, no trailing slash. Used for canonical links, sitemap.xml, social previews.
     ogImage: image shown when the site is shared on WhatsApp / Facebook / LinkedIn (1200x630 is ideal). */
  seo: {
    siteUrl: 'https://your-domain-here.com',
    siteName: 'Parklane',
    description: 'Explore residential properties for sale and rent in Jaipur, Gurgaon, Alwar and Delhi NCR with Parklane. Discover homes, compare locations and make informed property decisions.',
    ogImage: 'images/house3-4.webp',
    homeTitle: 'Homes for Sale & Rent in Jaipur, Gurgaon, Alwar | Parklane'
  },

  /* ---------- Brand & header ---------- */
  brand: {
    name: 'Parklane',
    logo: 'images/logow-sm.png',     // header + footer logo (white mark – both sit on the green gradient)
    favicon: 'images/logow-sm.png',  // browser-tab icon (leave out to reuse the logo)
    titleSuffix: 'Parklane'
  },
  nav: [ // label, link, isButton
    { label: 'Buy', href: 'buy.html' },
    { label: 'Sell', href: 'sell.html' },
    { label: 'Properties', href: 'properties.html' },
    { label: 'Agents', href: 'agents.html' },
    { label: 'About', href: 'about.html' },
    { label: 'Contact', href: 'contact.html', button: true }
  ],

  /* ---------- Contact & social links (ONE place to edit) ----------
     Used by: footer, About page, Contact page, agent profile on property pages.
     Leave a value '' until you have the real one – its icon then points to contact.html
     and `node build.js` prints a WARNING so you can't forget.
       email     : a real address, e.g. 'hello@yourdomain.com'  -> opens a Gmail compose window
       whatsapp  : digits only with country code, e.g. '919XXXXXXXXX' -> https://wa.me/<number>
       instagram : full profile URL, e.g. 'https://www.instagram.com/yourhandle/'
       phone     : display + tel: link, e.g. '+91 98XXX XXXXX'                                   */
  contact: {
    email: '',
    whatsapp: '',
    instagram: '',
    phone: '',
    emailSubject: 'Property enquiry',
    whatsappMessage: 'Hello Parklane, I would like to know more about your properties.'
  },

  /* ---------- Footer ---------- */
  footer: {
    about: 'Discover residential properties for sale and rent across Jaipur, Gurgaon, Alwar and Delhi NCR. Explore homes and take your next property step with Parklane.',
    columns: [
      { title: 'Properties', links: [['Buy', 'buy.html'], ['Rent', 'rent.html'], ['All listings', 'properties.html'], ['Locations', 'location.html']] },
      { title: 'Resources', links: [['Sell your property', 'sell.html'], ['Home valuation', 'valuation.html'], ['About', 'about.html']] }
    ],
    contactTitle: 'Get in touch',
    contactLines: ['Use the Contact page to send an enquiry.', 'Serving property searches across Jaipur, Gurgaon, Alwar and Delhi NCR.'],
    legal: '© Parklane. Verify listing details, availability and advisor credentials before making a property decision.'
  },

  /* ---------- Homepage ---------- */
  home: {
    hero: {
      image: 'images/house3-4.webp',
      alt: 'Bright open-plan kitchen and dining area in a family home',
      title: 'Find a place that<br>feels like home.',
      text: 'Thoughtfully selected homes for sale and rent across Jaipur, Gurgaon, Alwar and Delhi NCR.',
      primaryButton: 'Explore properties', primaryHref: 'properties.html',
      secondaryButton: 'Discover locations', secondaryHref: '#locations'
    },
    featured: { eyebrow: 'Featured', title: 'Featured Properties', note: 'Explore property examples and verify availability and details before arranging a viewing.', buttonText: 'View all properties' },
    locations: { eyebrow: 'Explore', title: 'Discover by location' },
    why: {
      title: 'Why choose us',
      items: [
        ['Personalised guidance', 'Advice shaped around your goals.'],
        ['Curated discovery', 'Homes selected, not just listed.'],
        ['Local knowledge', 'Neighbourhood-level insight.'],
        ['Full journey support', 'From first viewing to handover.']
      ]
    },
    sell: {
      eyebrow: 'Selling', title: 'Sell with clarity and care',
      text: 'A transparent process from consultation to closing. Outcomes are never guaranteed.',
      image: 'images/house8-6.webp', imageAlt: 'Bright, empty living room prepared for viewings', primaryButton: 'Sell your property', secondaryButton: 'Request a valuation'
    },
    valuation: {
      eyebrow: 'Valuation', title: 'What is your home worth?',
      text: 'No automated estimate – an advisor will contact you to discuss value.',
      placeholder: 'Address or location', button: 'Request valuation'
    },
    agentsTitle: 'Our agents',
    insights: {
      title: 'Insights', tag: 'Sample article',
      items: [ // title, image
        { title: 'Preparing a property for sale', image: 'images/house2-1.webp', alt: 'Light-filled living room with timber floors' },
        { title: 'Understanding the home-buying process', image: 'images/house3-3.webp', alt: 'Front door and pergola entrance of a home' },
        { title: 'Choosing the right neighbourhood', image: 'images/house6-5.webp', alt: 'Rooftop terrace overlooking a city neighbourhood' }
      ]
    }
  },

  /* ---------- Locations ----------
   Used for the homepage cards AND location.html (?location=<name as lowercase-with-dashes>, e.g. delhi-ncr).
   Properties appear on a location page when their `city` equals the location `name`. */
  locations: [
    { name: 'Jaipur', text: 'Heritage character with modern pockets.', image: 'images/house4-2.webp', alt: 'Residential building at dusk' },
    { name: 'Gurgaon', text: 'Corporate hub, high-rise living.', image: 'images/house7-1.webp', alt: 'High-rise residential towers' },
    { name: 'Alwar', text: 'Calm, green, great value.', image: 'images/house1-3.webp', alt: 'Single-storey home surrounded by green lawns' },
    { name: 'Delhi NCR', text: 'Established neighbourhoods.', image: 'images/house6-6.webp', alt: 'Aerial view of a dense residential neighbourhood' }
  ],

  /* ---------- Agents ----------
     Used for agents.html (?agent=<slug>). Each agent's properties are the ones whose `agent` index points at them. */
  // photo: '' uses the built-in illustration. Example: 'images/agents/aarav.jpg'
  agents: [
    { slug: 'aarav-mehta', name: 'Aarav Mehta', role: 'Senior Advisor', area: 'Jaipur', langs: 'English, Hindi', photo: '' },
    { slug: 'isha-kapoor', name: 'Isha Kapoor', role: 'Luxury Specialist', area: 'Gurgaon', langs: 'English, Hindi, Punjabi', photo: '' },
    { slug: 'vikram-rathore', name: 'Vikram Rathore', role: 'Property Consultant', area: 'Alwar', langs: 'English, Hindi, Rajasthani', photo: '' },
    { slug: 'neha-sharma', name: 'Neha Sharma', role: 'Buyer Advisor', area: 'Delhi NCR', langs: 'English, Hindi', photo: '' }
  ],
  agentIntro: '{name} helps buyers and renters in {area}. Share your requirements, preferred neighbourhood and budget, and {first} will talk you through relevant listings and next steps.',
  agentDesignation: 'Real Estate Agent',   // shown on the property page agent card (agents without their own role use this)
  agentSampleNote: 'Sample profile – replace with real agent details',  // set '' to hide once real agents are added
  agentBio: 'Explore residential property options in this advisor’s service area. Share your requirements, preferred location and priorities to discuss relevant listings and possible next steps. Please verify the advisor’s identity and credentials before relying on professional claims.',

  /* ---------- Property listings ----------
     agent   = position in the agents list above (0 = first agent)
     listing = 'buy' or 'rent'      price = number in rupees
     age     = days since added (smaller = newer)
     images  = photo paths (first = card/main image; any number; missing files are skipped with a build warning), e.g. ['images/willow-1.jpg', 'images/willow-2.jpg']
               leave [] to keep the built-in illustrations                    */
  properties: [
    { slug: 'willow-residence', title: 'The Willow Residence', city: 'Jaipur', state: 'Rajasthan', hood: 'Malviya Nagar', type: 'Villa', listing: 'buy', price: 32500000, beds: 4, baths: 4, area: 3800, agent: 0, age: 20, status: 'For sale', featured: true, images: ['images/house1-1.webp','images/house1-2.webp','images/house1-3.webp','images/house1-4.webp','images/house1-5.webp','images/house1-6.webp'] },
    { slug: 'aravalli-heights', title: 'Aravalli Heights', city: 'Gurgaon', state: 'Haryana', hood: 'Golf Course Rd', type: 'Apartment', listing: 'buy', price: 21000000, beds: 3, baths: 3, area: 2100, agent: 1, age: 18, status: 'For sale', featured: true, images: ['images/house2-1.webp','images/house2-2.webp','images/house2-3.webp','images/house2-4.webp','images/house2-5.webp','images/house2-6.webp'] },
    { slug: 'courtyard-house', title: 'The Courtyard House', city: 'Alwar', state: 'Rajasthan', hood: 'Civil Lines', type: 'House', listing: 'buy', price: 9800000, beds: 3, baths: 2, area: 2400, agent: 2, age: 16, status: 'For sale', featured: true, images: ['images/house3-1.webp','images/house3-2.webp','images/house3-3.webp','images/house3-4.webp','images/house3-5.webp','images/house3-6.webp'] },
    { slug: 'palm-grove-villa', title: 'Palm Grove Villa', city: 'Jaipur', state: 'Rajasthan', hood: 'Vaishali Nagar', type: 'Villa', listing: 'buy', price: 45000000, beds: 5, baths: 5, area: 5200, agent: 0, age: 14, status: 'Coming soon', featured: true, images: ['images/house4-1.webp','images/house4-2.webp','images/house4-3.webp','images/house4-4.webp','images/house4-5.webp','images/house4-6.webp'] },
    { slug: 'glasshouse', title: 'The Glasshouse', city: 'Delhi NCR', state: 'Delhi', hood: 'Vasant Vihar', type: 'House', listing: 'buy', price: 89000000, beds: 5, baths: 6, area: 6100, agent: 3, age: 12, status: 'For sale', featured: true, images: ['images/house5-1.webp','images/house5-2.webp','images/house5-3.webp','images/house5-4.webp'] },
    { slug: 'meadowview', title: 'Meadowview Apartment', city: 'Gurgaon', state: 'Haryana', hood: 'Sector 56', type: 'Apartment', listing: 'rent', price: 85000, beds: 2, baths: 2, area: 1350, agent: 1, age: 11, status: 'For rent', featured: true, images: ['images/house6-1.webp','images/house6-2.webp','images/house6-3.webp','images/house6-4.webp','images/house6-5.webp','images/house6-6.webp'] },
    { slug: 'ridge-estate', title: 'The Ridge Estate', city: 'Alwar', state: 'Rajasthan', hood: 'Siliserh Road', type: 'Villa', listing: 'buy', price: 27500000, beds: 4, baths: 4, area: 4300, agent: 2, age: 9, status: 'For sale', featured: false, images: ['images/house7-1.webp','images/house7-2.webp','images/house7-3.webp','images/house7-4.webp','images/house7-5.webp','images/house7-6.webp'] },
    { slug: 'gardenia', title: 'Gardenia Residences', city: 'Jaipur', state: 'Rajasthan', hood: 'C-Scheme', type: 'Apartment', listing: 'buy', price: 14200000, beds: 3, baths: 3, area: 1850, agent: 0, age: 8, status: 'Under offer', featured: false, images: ['images/house8-1.webp','images/house8-2.webp','images/house8-3.webp','images/house8-4.webp','images/house8-5.webp','images/house8-6.webp'] },
    { slug: 'sunrise-loft', title: 'Sunrise Loft', city: 'Delhi NCR', state: 'Delhi', hood: 'Saket', type: 'Apartment', listing: 'rent', price: 120000, beds: 2, baths: 2, area: 1500, agent: 3, age: 7, status: 'For rent', featured: false, images: ['images/house9-1.webp','images/house9-2.webp','images/house9-3.webp','images/house9-4.webp'] },
    { slug: 'orchard-lane', title: 'Orchard Lane Home', city: 'Alwar', state: 'Rajasthan', hood: 'Scheme 10', type: 'House', listing: 'buy', price: 6400000, beds: 2, baths: 2, area: 1700, agent: 2, age: 5, status: 'For sale', featured: false, images: [] },
    { slug: 'skyline-penthouse', title: 'Skyline Penthouse', city: 'Gurgaon', state: 'Haryana', hood: 'DLF Phase 5', type: 'Apartment', listing: 'buy', price: 52000000, beds: 4, baths: 5, area: 4100, agent: 1, age: 3, status: 'For sale', featured: false, images: [] },
    { slug: 'banyan-bungalow', title: 'Banyan Bungalow', city: 'Jaipur', state: 'Rajasthan', hood: 'Jawahar Nagar', type: 'House', listing: 'rent', price: 150000, beds: 4, baths: 3, area: 3000, agent: 0, age: 2, status: 'For rent', featured: false, images: [] }
  ],

  /* ---------- Property detail page text ----------
     {type} and {hood} are replaced automatically. */
  detail: {
    about: 'A fictional {type} in {hood}, designed for light, space and ease. Sample copy for demonstration only.',
    features: ['Landscaped garden', 'Open-plan living', 'Covered parking', 'Modular kitchen'],
    amenities: ['24x7 security', 'Power backup', 'Clubhouse access'],
    imageNote: 'All images'
  },

  /* ---------- Search filter options ---------- */
  filters: {
    types: ['Villa', 'Apartment', 'House'],
    statuses: ['For sale', 'For rent', 'Coming soon', 'Under offer'],
    minPrice: [[0, 'Min price'], [5e6, '₹50 L'], [1e7, '₹1 Cr'], [2e7, '₹2 Cr'], [5e7, '₹5 Cr']],
    maxPrice: [[1e12, 'Max price'], [1e7, '₹1 Cr'], [2e7, '₹2 Cr'], [5e7, '₹5 Cr'], [1e9, '₹100 Cr']],
    rooms: [[0, 'Any'], [2, '2+'], [3, '3+'], [4, '4+']],
    area: [[0, 'Any'], [1500, '1,500 sq ft'], [3000, '3,000 sq ft'], [5000, '5,000 sq ft']],
    perPage: 6
  },

  /* ---------- Inner pages ---------- */
  pages: {
    sell: {
      title: 'Sell your property',
      intro: 'Consultation, preparation, marketing, offers and closing – guided every step. No guaranteed prices or timelines.',
      steps: ['Initial consultation', 'Preparation and pricing discussion', 'Marketing and viewings', 'Offers and negotiation', 'Closing'],
      image: 'images/house8-6.webp', imageAlt: 'Bright, empty living room prepared for viewings',
      faqTitle: 'FAQ',
      faq: 'How is my home valued? An advisor reviews it with you – no automated estimate here.'
    },
    valuation: { image: 'images/house2-3.webp', imageAlt: 'Sunlit apartment living space with large windows', title: 'Home valuation', intro: 'Tell us about your property and an advisor can follow up. No fabricated estimate is shown.' },
    about: {
      title: 'About Parklane', metaTitle: 'About Parklane | A Thoughtful Approach to Real Estate',
      description: 'Learn about Parklane, a real estate platform for exploring homes for sale and rent in Jaipur, Gurgaon, Alwar and Delhi NCR.',
      image: 'images/house4-3.webp', imageAlt: 'Marble staircase with brass handrails in a residential building',
      eyebrow: 'About Parklane',
      heading: 'A better way to<br>find your place.',
      intro: 'A home is more than an address. It is where life takes shape, ambitions grow and everyday moments become lasting memories. Parklane helps make property discovery feel more considered, clear and personal.',
      value: { eyebrow: 'What we offer', title: 'Property decisions, made personal.', text: 'Every buyer, renter and property owner has different priorities. You may be looking for your first home, a rental closer to work, more room for your family or the next step in your property journey. We help you explore options and focus on what matters to you.' },
      approach: {
        title: 'Our approach',
        items: [
          ['Personalised guidance', 'Start with your needs, preferences and budget.'],
          ['Thoughtful discovery', 'Explore organised property listings and useful details to compare available options.'],
          ['Local perspective', 'Consider the character of different neighbourhoods and the practical factors that matter in everyday life.'],
          ['Clarity at every step', 'From your first search to a viewing request or a selling enquiry, we aim to make the process easier to understand. Property details and availability should always be independently verified.']
        ]
      },
      places: { title: 'Discover places with potential.', text: 'From Jaipur\u2019s distinctive character to Gurgaon\u2019s contemporary lifestyle, Alwar\u2019s quieter surroundings and the diverse neighbourhoods of Delhi NCR, each location offers a different way of living. Explore listings by location and consider the neighbourhood, convenience and lifestyle that come with a home.', linkText: 'Explore locations', linkHref: 'location.html' },
      cta: { title: 'Find your next chapter with Parklane.', text: 'Whether you are searching for a home, exploring rental options or considering selling a property, Parklane gives you a place to begin.', primary: 'Explore properties', secondary: 'Get in touch', socialTitle: 'Reach us directly' }
    },
    contact: { image: 'images/house3-2.webp', imageAlt: 'Sunlit garden path leading to a home entrance', title: 'Contact Parklane', metaTitle: 'Contact Parklane | Property Enquiries', description: 'Contact Parklane about residential property searches, buying, renting, selling or valuation enquiries in Jaipur, Gurgaon, Alwar and Delhi NCR.', intro: 'Have a property question or want to discuss your requirements? Send an enquiry using the form on this page. Please do not include sensitive personal or financial information.' },
    privacy: { title: 'Privacy Policy', metaTitle: 'Privacy Policy | Parklane', description: 'Read how Parklane may collect, use, store and share information submitted through property enquiries and website features.', intro: 'Last updated: 24 October 2026. This policy must be checked against the actual services and data practices used by the website before publication.', extra: `<h2>1. Introduction</h2><p>Parklane ("we", "our" or "us") aims to handle personal information responsibly. This policy explains how information may be collected and used when you browse listings, create an account or submit a property enquiry. Where required by law, we will seek consent separately.</p><h2>2. Information we may collect</h2><p>Depending on the features you use, information may include your name, email address, phone number, account details, property preferences, preferred locations, budget range and details submitted through contact, valuation, buying, renting or selling forms. Website hosting or enabled analytics services may also process technical information such as browser type, device details, pages visited and diagnostic logs.</p><h2>3. How information may be used</h2><ul><li>Respond to property enquiries and requests for information.</li><li>Discuss property preferences, viewings and valuation requests.</li><li>Operate accounts and website features you request.</li><li>Maintain security, troubleshoot issues and improve the website.</li><li>Measure website performance where analytics are enabled.</li><li>Meet applicable legal obligations and address disputes.</li></ul><h2>4. Sharing information</h2><p>Relevant information may be shared with service providers that host the website, process forms, deliver communications, support analytics or maintain security. Information may be shared with a relevant advisor or service partner when needed to respond to your request, or disclosed when required by law. The actual recipients depend on the services configured on this website.</p><h2>5. Cookies and analytics</h2><p>The website or third-party tools may use cookies or similar technologies for essential functionality, preferences or analytics if those tools are enabled. Update this section to name the tools actually used and explain any consent choices offered.</p><h2>6. Retention and security</h2><p>Information should be retained only as long as reasonably necessary for the stated purpose, unless a longer period is required or permitted by law. Reasonable safeguards should be used to protect information, but no online system can be guaranteed completely secure.</p><h2>7. Your choices and requests</h2><p>Subject to applicable law, you may be able to request access to, correction of or deletion of your information, or withdraw consent where processing relies on consent. Contact Parklane using the verified contact details published on the website. Some information may need to be retained for legal purposes.</p><h2>8. Third-party links</h2><p>External websites and services operate under their own privacy policies. Review those policies before sharing information with them.</p><h2>9. Children's privacy</h2><p>If you believe a child has provided information in circumstances where this is not permitted, contact the website operator so the matter can be reviewed under applicable law.</p><h2>10. Changes</h2><p>This policy may be updated as the website, services or legal requirements change. The revised version will be published on this page.</p><h2>11. Contact</h2><p>For privacy requests, use the verified contact details on the <a href='contact.html'>Contact page</a>. Add a monitored privacy email and the legal identity/address of the website operator before launch.</p><p><strong>Important:</strong> This is a general draft, not legal advice. Confirm actual data flows, form handling, hosting, analytics, retention and applicable Indian privacy requirements with a qualified professional before publishing.</p>` },
    terms: { title: 'Terms of Use', metaTitle: 'Terms of Use | Parklane', description: 'Review the terms governing use of Parklane property listings, location information and property enquiry features.', intro: 'Last updated: 24 October 2026. These terms are a general draft and should be reviewed for your actual business model before publication.', extra: `<h2>1. Introduction</h2><p>These Terms of Use govern access to the Parklane website and its property-related features. By using the website, you agree to these terms to the extent permitted by applicable law. If you do not agree, please stop using the website.</p><h2>2. Website purpose</h2><p>Parklane provides an online platform for discovering residential properties, exploring locations and submitting enquiries about buying, renting, selling or property valuation. Unless separately agreed in writing, browsing the website or submitting an enquiry does not by itself create an agency, brokerage or advisory relationship.</p><h2>3. Listings and accuracy</h2><p>Property details may be provided by owners, agents, developers or other sources and may be incomplete, outdated or subject to change. Availability, measurements, features, ownership, approvals, costs and other details should be independently verified before making a decision. Images may be illustrative and may not reflect the property's current condition.</p><h2>4. Independent checks</h2><p>Before proceeding with a transaction, independently review relevant title and ownership records, approvals, registrations, costs and contractual conditions. Seek qualified legal, financial or property advice where appropriate. Website information is not a guarantee of value, availability, suitability or a particular outcome.</p><h2>5. Enquiries and accounts</h2><p>Provide accurate information when submitting an enquiry or creating an account. Keep account credentials confidential and do not submit another person's personal information without appropriate authority. Submitting a form does not guarantee a response within a particular timeframe, a viewing or property availability.</p><h2>6. Acceptable use</h2><ul><li>Do not use the website for unlawful, fraudulent or misleading purposes.</li><li>Do not impersonate another person or submit intentionally false enquiries.</li><li>Do not attempt unauthorised access to systems, accounts or data.</li><li>Do not interfere with website security or availability.</li><li>Do not scrape, republish or commercially exploit protected content without permission or another lawful basis.</li><li>Do not upload malicious code or misuse website forms.</li></ul><h2>7. Intellectual property</h2><p>Unless stated otherwise, original website text, branding, design elements and graphics are owned by the operator or used with permission or another lawful basis. Property photographs, trademarks and third-party materials may belong to their respective owners. You may not reproduce or commercially use protected material without permission, except where permitted by law.</p><h2>8. Third-party services</h2><p>Links and third-party services may be provided for convenience. Those services operate under their own terms, and Parklane does not control independent third-party websites.</p><h2>9. Availability and changes</h2><p>Website content and features may change for maintenance, security or operational reasons. Continuous, error-free access is not guaranteed.</p><h2>10. Liability</h2><p>To the extent permitted by law, the website operator is not responsible for losses arising from reliance on unverified listing information, changes in availability, third-party conduct or temporary interruptions. Nothing in these terms excludes or limits liability where doing so is prohibited by law or removes statutory rights that cannot be excluded.</p><h2>11. Privacy</h2><p>Use of the website is also subject to the <a href='privacy.html'>Privacy Policy</a>.</p><h2>12. Applicable law and disputes</h2><p>These terms are subject to the laws of India to the extent applicable. Disputes will be handled by competent courts or other lawful dispute-resolution procedures, without removing rights that cannot legally be excluded.</p><h2>13. Changes and contact</h2><p>Terms may be updated from time to time and the current version will appear on this page. For questions, use the verified details on the <a href='contact.html'>Contact page</a>. Insert the operator's legal identity and business address before launch.</p><p><strong>Important:</strong> This is a general draft, not legal advice. Have the final terms reviewed by a qualified Indian legal professional.</p>` }
  },

  /* ---------- Form messages ---------- */
  forms: {
    action: '', // leave '' for demo mode. Put your form service URL here (Formspree, Netlify, your API) to send real submissions.
    demoNote: 'Demo only – nothing is sent to a real brokerage.',
    success: '<b>Thank you.</b> Your demo request was captured in the browser only. A real build would send it to a CRM or email service.'
  }
};

if (typeof module !== 'undefined') module.exports = CONFIG;
