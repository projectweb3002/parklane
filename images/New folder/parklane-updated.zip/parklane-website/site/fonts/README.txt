Put your licensed font files here (woff2 preferred), then run: node build.js

Expected file names:
  NeueMontreal-Regular.woff2   -> Neue Montreal 400
  NeueMontreal-Medium.woff2   -> Neue Montreal 500
  NeueMontreal-Bold.woff2   -> Neue Montreal 700
  Canela-Regular.woff2   -> Canela 400

Canela is used for H1 headings; Neue Montreal for H2, H3, the Parklane logo text and body text.
Neue Montreal Medium is used for headings; if you only have Regular, it is used instead.
